package com.crud.example.controller;

import com.crud.example.entity.Product;
import com.crud.example.service.ProductService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import javax.validation.Valid;

@RestController
public class ProductController {

    @Autowired
    private ProductService service;

    @PostMapping("/addItem")
    
    public Product addProduct(@Valid @RequestBody Product product) {
    	return service.saveProduct(product);
    }

    @PostMapping("/addItems")
    public List<Product> addProducts(@Valid @RequestBody List<Product> products) {
        return service.saveProducts(products);
    }

    @GetMapping("/items")
    public List<Product> findAllProducts() {
        return service.getProducts();
    }

    @GetMapping("/itemById/{id}")
    public Product findProductById(@Valid @PathVariable int id) {
        return service.getProductById(id);
    }

    @PutMapping("/update")
    public Product updateProduct(@Valid @RequestBody Product product) {
        return service.updateProduct(product);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteProduct(@ Valid @PathVariable int id) {
        return service.deleteProduct(id);
    }
}
