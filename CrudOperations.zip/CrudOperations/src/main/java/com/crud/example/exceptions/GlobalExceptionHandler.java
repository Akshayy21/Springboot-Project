package com.crud.example.exceptions;

public class GlobalExceptionHandler {

	public static void main(String[] args) {
		

	}

}
