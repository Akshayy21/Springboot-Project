 package com.crud.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudOperations {

	public static void main(String[] args) {
		SpringApplication.run(CrudOperations.class, args);
	}

}
