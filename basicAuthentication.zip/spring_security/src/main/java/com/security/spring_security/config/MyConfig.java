package com.security.spring_security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.security.spring_security.models.CustomUserDetail;
import com.security.spring_security.services.CustomUserDetailService;

@Configuration
@EnableWebSecurity
public class MyConfig extends WebSecurityConfigurerAdapter{

	@Autowired
	private CustomUserDetailService customUserDetailService;
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.csrf().disable()
		.authorizeRequests()
		.antMatchers("/public/***").hasRole("NORMAL")
		.antMatchers("/users/**").hasRole("ADMIN")
		.anyRequest()
		.authenticated()
		.and()
		.formLogin();
	}

//	@Override
//	  protected void configure(HttpSecurity http) throws Exception {  // (2)
//	      http
//	        .authorizeRequests()
//	          .antMatchers("/", "/home").permitAll() // (3)
//	          .anyRequest().authenticated() // (4)
//	          .and()
//	       .formLogin() // (5)
//	         .loginPage("/login") // (5)
//	         .permitAll()
//	         .and()
//	      .logout() // (6)
//	        .permitAll()
//	        .and()
//	      .httpBasic(); // (7)
//	  }
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		
		auth.userDetailsService(customUserDetailService).passwordEncoder(passwordEncoder());
		// auth.inMemoryAuthentication().withUser("akshay").password(this.passwordEncoder().encode("abcdef")).roles("NORMAL");
		// auth.inMemoryAuthentication().withUser("harish").password(this.passwordEncoder().encode("123456")).roles("ADMIN");
	}

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		
		return new BCryptPasswordEncoder(10);
	}
	
	
}
