package com.security.spring_security.services;

import java.util.List;

import org.springframework.stereotype.Service;

import java.util.ArrayList;

import com.security.spring_security.models.User;

@Service
public class UserService {
	
	List<User> list=new ArrayList<>();
	
	public UserService() {
		list.add(new User("akshay","abcdef","akshay@gmail.com","ROLE_NORMAL"));
		list.add(new User("harish","123456","harish@gmail.com","ROLE_ADMIN"));
	}

	public List<User> getAllUsers()
	{
		return this.list;
	}
	
	public User getUser(String username)
	{
		return this.list.stream().filter((user)-> user.getUsername().equals(username)).findAny().orElse(null);
	}
	
	public User addUser(User user)
	{
		this.list.add(user);
		return user;
	}

}
