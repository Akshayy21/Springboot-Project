package com.security.spring_security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.security.spring_security.models.User;
import com.security.spring_security.repository.UserRepository;

@SpringBootApplication
public class SpringSecurityApplication implements CommandLineRunner {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		User user1=new User();
		user1.setEmail("akshay@gmail.com");
		user1.setUsername("akshay");
		user1.setPassword(this.bCryptPasswordEncoder.encode("abcdef"));
		user1.setRole("ROLE_NORMAL");
		this.userRepository.save(user1);
		
		User user2=new User();
		user2.setEmail("harish@gmail.com");
		user2.setUsername("harish");
		user2.setPassword(this.bCryptPasswordEncoder.encode("123456"));
		user2.setRole("ROLE_ADMIN");
		
		this.userRepository.save(user2);

		
	}

	
}
