package com.security.spring_security.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/public")
public class HomePageController {

	 @GetMapping("/home")
	public String home()
	{
		return "this is the home page";
	}
	 
	 @GetMapping("/signup")
		public String login()
		{
			return "this is the signup page";
		}
	 
	 @GetMapping("/signin")
		public String register()
		{
			return "this is the signin page";
		}
}
