package com.mapping.onetomany;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mapping.entity.Address;
import com.mapping.entity.StudentInformation;
import com.mapping.repository.AddressRepo;
import com.mapping.repository.StudentRepo;

@SpringBootApplication
public class OnetomanyApplication implements CommandLineRunner {

	@Autowired 
	StudentRepo student1;
	@Autowired 
	AddressRepo student2;
	public static void main(String[] args)
	{
		SpringApplication.run(OnetomanyApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception
	{
		StudentInformation student = new StudentInformation(1, "Akshay");
		student1.save(student);
		Address address = new Address(1, "Delhi", student);
		student2.save(address);
	}
}
