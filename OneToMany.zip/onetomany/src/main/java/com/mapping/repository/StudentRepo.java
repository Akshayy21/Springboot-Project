package com.mapping.repository;

import com.mapping.entity.StudentInformation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepo extends JpaRepository<StudentInformation, Integer> {
}

