package com.mapping.entity;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class StudentInformation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;

	@OneToMany(cascade = CascadeType.ALL)
	private Set<Address> address1;
	public int getRollno() { 
		return id; 
		}

	public StudentInformation() 
	{
		
	}

	public StudentInformation(int rollno, String name)
	{
		this.id = rollno;
		this.name = name;
	}

	public void setRollno(int rollno)
	{

		this.id = rollno;
	}

	public String getName() { 
		return name; 
		}

	public void setName(String name) { 
		this.name = name; 
		}
}

