package com.mapping.entity;

import javax.persistence.*;

@Entity
@Table(name = "Address")
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String address;

	@ManyToOne
	@JoinColumn(name = "student id")
	StudentInformation info1;

	Address() {}

	public Address(int id, String address, StudentInformation info1)
	{
		this.id = id;
		this.address = address;
		this.info1 = info1;
	}
}
